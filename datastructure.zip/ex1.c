#include <stdio.h>

int main(){
    printf("%d ", sizeof(char));
    return 0;

}